import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.dao.EmployeeDAO;
import com.capgemini.dao.EmployeeDAOImpl;
import com.capgemini.dto.EmployeeDTO;

public class EmployeeDAOImplTest {
	
	private EmployeeDAO daoref;

	@Before
	public void setup(){
		
		System.out.println("DAO instantiated");
		daoref = new EmployeeDAOImpl();
		
	}
	
	@Test
	public void findId(){
		
		int id = 2;
		EmployeeDTO employee = daoref.findId(id);
		Assert.assertNotNull(employee);
		Assert.assertEquals(id, employee.getId());
	}
	
	@After
	public void done(){
		System.out.println("Done");
		daoref = null;
	}
	
	
	
	
	
	@Test
	@Ignore
	public void testOp(){
		
		String message = "Hey,World";
		String message2 = "Hey,World";
		
		Assert.assertEquals(message, message2);
		
		
	}
	

}
