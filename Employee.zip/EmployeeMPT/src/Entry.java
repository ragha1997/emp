import java.util.Date;

import com.capgemini.dao.EmployeeDAO;
import com.capgemini.dao.EmployeeDAOImpl;
import com.capgemini.dto.EmployeeDTO;



public class Entry {
	
	public static void main(String[] args) {
		
		EmployeeDAO daoref = new EmployeeDAOImpl();
		
		EmployeeDTO employee = new EmployeeDTO();
		employee.setName("Kuchbhi");
		employee.setJoindate(new Date());
		
		daoref.createEmployee(employee);
		
		
		
	}
	
	

}
