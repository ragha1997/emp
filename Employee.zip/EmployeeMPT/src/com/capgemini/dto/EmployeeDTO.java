package com.capgemini.dto;

import java.util.Date;

public class EmployeeDTO {

	private int id;
	private String name;
	private Date joindate;
	
	public int getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public Date getJoindate() {
		return joindate;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setJoindate(Date joindate) {
		this.joindate = joindate;
	}
	
}
