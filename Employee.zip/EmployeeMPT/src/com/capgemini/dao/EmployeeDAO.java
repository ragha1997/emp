package com.capgemini.dao;

import com.capgemini.dto.EmployeeDTO;

public interface EmployeeDAO {
	
	public boolean createEmployee(EmployeeDTO employee);
	public EmployeeDTO findId(int id);

}
