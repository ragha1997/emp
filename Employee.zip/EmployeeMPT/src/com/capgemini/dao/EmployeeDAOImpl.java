package com.capgemini.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.capgemini.dto.EmployeeDTO;
import com.capgemini.utils.DBUtils;
import com.capgemini.utils.Log4jHTMLLayout;

public class EmployeeDAOImpl implements EmployeeDAO {
	
	private static Logger log = Logger.getLogger(Log4jHTMLLayout.class);

private Connection dbConnection;	// ???
	
	{
		
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	

	private int generateNextEmployeeId() throws SQLException{
		
		int id = 0;
		
		String selectQuery = "select orderseq.nextval from dual";
		
		Statement selectStatement = dbConnection.createStatement();
		ResultSet result = selectStatement.executeQuery(selectQuery);
		
		result.next();
		
		id = result.getInt(1);
		return id;
		
	}
	
	
	
	
	
	
	public boolean createEmployee(EmployeeDTO employee){
		
		String insertQuery = "insert into Empl values(?,?,?)";
		
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
			
			
			
			insertStatement.setInt(1, generateNextEmployeeId());
			
			insertStatement.setString(2, employee.getName());
			
			Date orderDate = new Date(employee.getJoindate().getTime());
			
			insertStatement.setDate(3, orderDate);
			
			int rows = insertStatement.executeUpdate();
			
			if(rows > 0){
				System.out.println("Row is added into db");
				log.info("Added a row in db now...");
				return true;
			}
				
			else
				return false;
		} catch (SQLException e) {
			e.printStackTrace();
			log.error(e.getMessage());
			return false;
		}
	}
	
	@Override
	public EmployeeDTO findId(int id) {

		String selectQuery = "select * from Empl where EmpID = ?";
		
		try {
			PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);
					
			selectStatement.setInt(1, id);
			
			ResultSet result = selectStatement.executeQuery();
			
			while(result.next()){
				
				int Empid = result.getInt(1);
				String Empname = result.getString(2);
				Date joinDateSQL =  result.getDate(3);
				
				java.util.Date joinDate = new java.util.Date(joinDateSQL.getTime());
				
				EmployeeDTO employee = new EmployeeDTO();
				employee.setId(Empid);
				employee.setJoindate(joinDate);
				
				return employee;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}	
	
}
